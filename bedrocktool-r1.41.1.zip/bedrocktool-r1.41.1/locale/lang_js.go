package locale

func getLanguageName() string {
	return "en"
}
