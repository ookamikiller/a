//go:build js

package updater

func DoUpdate() error {
	return nil
}
